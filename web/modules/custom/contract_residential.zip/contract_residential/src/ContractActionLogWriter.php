<?php

namespace Drupal\contract_residential;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityStorageException;

/**
 * Writes append-only contract_action_log rows for contract status transitions.
 *
 * Invariants:
 * - One row per successful action execution (after contract save).
 * - Append-only; no updates.
 */
final class ContractActionLogWriter {

  /**
   * Write a log row for a successful status transition.
   *
   * @param \Drupal\Core\Entity\EntityInterface $contract
   *   Contract entity (entity type: contracts).
   * @param string $action_key
   *   Machine-readable action key. Recommended: VBO action plugin id.
   * @param int $from_tid
   *   Prior contract_status term ID (0 if none).
   * @param int $to_tid
   *   New contract_status term ID.
   * @param bool $admin_override
   *   TRUE if administrator override path used.
   * @param string $actor
   *   Allowed values: staff|client|system (matches field_actor list).
   * @param string|null $context
   *   Optional context / reason / metadata. Keep short; not required.
   *
   * @return bool
   *   TRUE if saved, FALSE if not saved (missing fields/type or save failure).
   */
  public static function write(
    EntityInterface $contract,
    string $action_key,
    int $from_tid,
    int $to_tid,
    bool $admin_override,
    string $actor = 'staff',
    ?string $context = NULL
  ): bool {

    // Safety: only for contracts.
    if ($contract->getEntityTypeId() !== 'contracts') {
      return FALSE;
    }

    // Ensure logging entity type exists.
    $entity_type_manager = \Drupal::entityTypeManager();
    $definition = $entity_type_manager->getDefinition('contract_action_log', FALSE);
    if (!$definition) {
      return FALSE;
    }

    $storage = $entity_type_manager->getStorage('contract_action_log');

    /** @var \Drupal\Core\Entity\EntityInterface $log */
    $log = $storage->create([
      'type' => 'log',
    ]);

    // Base field: who.
    $uid = (int) \Drupal::currentUser()->id();
    if ($log->hasField('uid')) {
      $log->set('uid', $uid);
    }

    // Required bundle fields.
    if (!$log->hasField('field_contract')
      || !$log->hasField('field_action')
      || !$log->hasField('field_to_status')
      || !$log->hasField('field_admin_override')
      || !$log->hasField('field_actor')
    ) {
      return FALSE;
    }

    $log->set('field_contract', $contract->id());
    $log->set('field_action', $action_key);
    $log->set('field_to_status', $to_tid);
    $log->set('field_admin_override', $admin_override ? 1 : 0);
    $log->set('field_actor', $actor);

    // Optional fields.
    if ($log->hasField('field_from_status') && $from_tid > 0) {
      $log->set('field_from_status', $from_tid);
    }

    if ($context !== NULL && $context !== '' && $log->hasField('field_context')) {
      $log->set('field_context', $context);
    }

    try {
      $log->save();
      return TRUE;
    }
    catch (EntityStorageException $e) {
      // We do not block the action if logging fails; we simply report.
      \Drupal::messenger()->addError(t('Contract Action Log write failed: @msg', [
        '@msg' => $e->getMessage(),
      ]));
      return FALSE;
    }
  }

}
