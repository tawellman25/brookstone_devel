<?php

namespace Drupal\contract_residential\WorkOrderEnrichers;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\contract_residential\Service\WorkOrderGenerationResult;
use Drupal\taxonomy\TermInterface;

/**
 * Enrichment: default fertilizing seasons on WO when not explicitly set.
 *
 * Rules:
 * - If WO has field_fertilizing_season and it is empty:
 *   - default to Spring + Summer + Fall
 *   - add Early Spring (Pre-season) iff:
 *     - Property fertilizing info has field_turf_pre_emergent_property truthy, OR
 *     - Section indicates pre-season (via season term name or boolean/list field name).
 *
 * Notes:
 * - If section already sets field_fertilizing_season, CopySectionFieldsEnricher
 *   should have copied it first; in that case we do nothing (WO not empty).
 * - This enricher is additive and never overwrites.
 */
final class FertilizingSeasonsEnricher implements EnricherInterface {

  private EntityTypeManagerInterface $etm;

  /**
   * Cache: season term IDs by vid + normalized name.
   *
   * @var array<string,array<string,int>>
   */
  private array $seasonTidCache = [];

  public function __construct(EntityTypeManagerInterface $etm) {
    $this->etm = $etm;
  }

  public function apply(
    EntityInterface $contract,
    EntityInterface $section,
    TermInterface $service,
    EntityInterface $work_order,
    array $context,
    WorkOrderGenerationResult $result,
    array $options
  ): void {
    // Only act if the WO bundle supports season refs and it's empty.
    if (!$work_order->hasField('field_fertilizing_season')) {
      return;
    }
    if (!$work_order->get('field_fertilizing_season')->isEmpty()) {
      return;
    }

    // Only apply on fertilizing-related work orders (safety guard).
    $wo_bundle = (string) ($context['wo_bundle'] ?? '');
    if ($wo_bundle === '' || stripos($wo_bundle, 'fertiliz') === FALSE) {
      return;
    }

    // field_fertilizing_season must be an entity reference to taxonomy_term.
    $def = $work_order->getFieldDefinition('field_fertilizing_season');
    $settings = $def ? $def->getSettings() : [];
    $target_type = $settings['target_type'] ?? '';
    if ($target_type !== 'taxonomy_term') {
      // If you ever implement this as a list field, we can extend later.
      return;
    }

    // Determine vocabulary (target bundle/vid) for the season field.
    $vids = $this->getTargetVocabularies($def);
    if (empty($vids)) {
      return;
    }
    // Use the first allowed vid (field typically restricts to one).
    $vid = (string) reset($vids);

    // Default program: Spring, Summer, Fall.
    $term_ids = [];
    foreach (['spring', 'summer', 'fall'] as $key) {
      $tid = $this->findSeasonTid($vid, $key);
      if ($tid) {
        $term_ids[] = $tid;
      }
    }

    if (empty($term_ids)) {
      // Can't resolve seasons; avoid guessing.
      return;
    }

    // Add early spring / pre-season if property flag OR section indicates.
    $needs_preseason = $this->propertyIsTurfPreEmergent($contract) || $this->sectionIndicatesPreSeason($section);
    if ($needs_preseason) {
      // Try common labels.
      $pre_tid = $this->findSeasonTid($vid, 'early_spring');
      if (!$pre_tid) {
        $pre_tid = $this->findSeasonTid($vid, 'preseason');
      }
      if (!$pre_tid) {
        $pre_tid = $this->findSeasonTid($vid, 'pre_season');
      }
      if ($pre_tid) {
        $term_ids[] = $pre_tid;
      }
    }

    // De-dupe and set.
    $term_ids = array_values(array_unique(array_map('intval', $term_ids)));
    $values = array_map(static fn(int $tid) => ['target_id' => $tid], $term_ids);
    $work_order->set('field_fertilizing_season', $values);

    $sid = (int) $section->id();
    $result->addMessage("Section {$sid}: defaulted fertilizing season(s) on Work Order (" . count($term_ids) . ").");
  }

  /**
   * Determine target vocabularies for a taxonomy term reference field.
   *
   * @param \Drupal\Core\Field\FieldDefinitionInterface|null $def
   * @return string[]
   */
  private function getTargetVocabularies($def): array {
    if (!$def) {
      return [];
    }
    $settings = $def->getSetting('handler_settings') ?? [];
    $bundles = $settings['target_bundles'] ?? [];
    if (!is_array($bundles) || empty($bundles)) {
      return [];
    }
    return array_values(array_filter(array_map('strval', $bundles)));
  }

  /**
   * Find season term tid by normalized key within a vid.
   *
   * Keys supported:
   * - spring/summer/fall
   * - early_spring / preseason / pre_season
   */
  private function findSeasonTid(string $vid, string $key): ?int {
    $key_norm = strtolower(trim($key));
    $key_norm = str_replace(['-', ' '], '_', $key_norm);

    if (!isset($this->seasonTidCache[$vid])) {
      $this->seasonTidCache[$vid] = $this->buildSeasonMapForVid($vid);
    }

    // Direct match.
    if (isset($this->seasonTidCache[$vid][$key_norm])) {
      return (int) $this->seasonTidCache[$vid][$key_norm];
    }

    // Loose fallback: look for contains tokens.
    foreach ($this->seasonTidCache[$vid] as $name_norm => $tid) {
      if ($key_norm === 'spring' && strpos($name_norm, 'spring') !== FALSE && strpos($name_norm, 'early') === FALSE) {
        return (int) $tid;
      }
      if ($key_norm === 'summer' && strpos($name_norm, 'summer') !== FALSE) {
        return (int) $tid;
      }
      if (($key_norm === 'fall') && (strpos($name_norm, 'fall') !== FALSE || strpos($name_norm, 'autumn') !== FALSE)) {
        return (int) $tid;
      }
      if (in_array($key_norm, ['early_spring', 'preseason', 'pre_season'], TRUE)) {
        if ((strpos($name_norm, 'early') !== FALSE && strpos($name_norm, 'spring') !== FALSE) || strpos($name_norm, 'pre') !== FALSE) {
          return (int) $tid;
        }
      }
    }

    return NULL;
  }

  /**
   * Build map of normalized term names -> tid for a vocabulary.
   *
   * @return array<string,int>
   */
  private function buildSeasonMapForVid(string $vid): array {
    $map = [];

    $ids = $this->etm->getStorage('taxonomy_term')->getQuery()
      ->accessCheck(FALSE)
      ->condition('vid', $vid)
      ->execute();

    if (!$ids) {
      return $map;
    }

    $terms = $this->etm->getStorage('taxonomy_term')->loadMultiple($ids);
    foreach ($terms as $term) {
      if (!$term instanceof TermInterface) {
        continue;
      }
      $name = strtolower(trim((string) $term->label()));
      $name = str_replace(['-', ' '], '_', $name);
      $name = preg_replace('/_+/', '_', $name);
      if ($name !== '') {
        $map[$name] = (int) $term->id();
      }
    }

    return $map;
  }

  /**
   * Determine if Property fertilizing info indicates turf pre-emergent property.
   *
   * We do NOT hardcode the property reference field name. We search the Property’s
   * entity_reference fields for target_type == 'property_fertilizing_info' and use the first.
   */
  private function propertyIsTurfPreEmergent(EntityInterface $contract): bool {
    if (!$contract->hasField('field_property') || $contract->get('field_property')->isEmpty()) {
      return FALSE;
    }
    $property_id = (int) $contract->get('field_property')->target_id;
    if ($property_id <= 0) {
      return FALSE;
    }

    $property = $this->etm->getStorage('properties')->load($property_id);
    if (!$property instanceof EntityInterface) {
      return FALSE;
    }

    // Find a reference field on Property that targets property_fertilizing_info.
    $fert_info_entity = NULL;

    foreach ($property->getFieldDefinitions() as $field_name => $field_def) {
      $type = $field_def->getType();
      if ($type !== 'entity_reference') {
        continue;
      }
      $settings = $field_def->getSettings();
      $target_type = $settings['target_type'] ?? '';
      if ($target_type !== 'property_fertilizing_info') {
        continue;
      }
      if ($property->get($field_name)->isEmpty()) {
        continue;
      }
      $fert_info_entity = $property->get($field_name)->entity;
      if ($fert_info_entity instanceof EntityInterface) {
        break;
      }
    }

    if (!$fert_info_entity instanceof EntityInterface) {
      return FALSE;
    }

    if (!$fert_info_entity->hasField('field_turf_pre_emergent_property') || $fert_info_entity->get('field_turf_pre_emergent_property')->isEmpty()) {
      return FALSE;
    }

    // Support boolean and list_boolean-ish values.
    $v = $fert_info_entity->get('field_turf_pre_emergent_property')->value;
    return ($v === '1' || $v === 1 || $v === TRUE || $v === 'true');
  }

  /**
   * Determine if section indicates pre-season.
   */
  private function sectionIndicatesPreSeason(EntityInterface $section): bool {
    // A) If section has a season field and it includes an early/pre term, treat as pre-season.
    if ($section->hasField('field_fertilizing_season') && !$section->get('field_fertilizing_season')->isEmpty()) {
      foreach ($section->get('field_fertilizing_season')->referencedEntities() as $term) {
        if ($term instanceof TermInterface) {
          $name = strtolower((string) $term->label());
          if ((strpos($name, 'early') !== FALSE && strpos($name, 'spring') !== FALSE) || strpos($name, 'pre') !== FALSE) {
            return TRUE;
          }
        }
      }
    }

    // B) Look for any boolean/list field containing pre_season/preseason in the machine name.
    foreach ($section->getFieldDefinitions() as $field_name => $field_def) {
      if (strpos($field_name, 'preseason') === FALSE && strpos($field_name, 'pre_season') === FALSE && strpos($field_name, 'pre-season') === FALSE) {
        continue;
      }
      if (!$section->hasField($field_name) || $section->get($field_name)->isEmpty()) {
        continue;
      }
      $v = $section->get($field_name)->value;
      if ($v === '1' || $v === 1 || $v === TRUE || $v === 'true') {
        return TRUE;
      }
    }

    return FALSE;
  }

}
