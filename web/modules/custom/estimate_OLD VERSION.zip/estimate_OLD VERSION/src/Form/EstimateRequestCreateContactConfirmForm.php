<?php

declare(strict_types=1);

namespace Drupal\estimate\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Url;
use Drupal\contract_residential\Service\ContactCreator;
use Drupal\contract_residential\Service\ContactResolver;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Confirm form to create (or link) a Contact from an Estimate Request.
 */
final class EstimateRequestCreateContactConfirmForm extends ConfirmFormBase {

  private EntityInterface $estimateRequest;

  public function __construct(
    private readonly ContactResolver $contactResolver,
    private readonly ContactCreator $contactCreator,
  ) {}

  public static function create(ContainerInterface $container): self {
    return new self(
      $container->get('estimate.contact_resolver'),
      $container->get('estimate.contact_creator'),
    );
  }

  public function getFormId(): string {
    return 'contract_residential_estimate_request_create_contact_confirm';
  }

  public function getQuestion(): string {
    return $this->t('Create a Contact for this Estimate Request?');
  }

  public function getCancelUrl(): Url {
    return $this->estimateRequest->toUrl('canonical');
  }

  public function getConfirmText(): string {
    return $this->t('Create Contact');
  }

  public function buildForm(array $form, FormStateInterface $form_state, EntityInterface $estimate_request = NULL): array {
    if (!$estimate_request) {
      throw new \InvalidArgumentException('Missing estimate_request parameter.');
    }
    $this->estimateRequest = $estimate_request;

    // If already linked, bail.
    if ($estimate_request->hasField('field_contact') && !$estimate_request->get('field_contact')->isEmpty()) {
      $this->messenger()->addWarning('This Estimate Request already has a Contact linked.');
      return $this->redirect($estimate_request->toUrl('canonical')->toString());
    }

    // Gather intake data from request.
    $payload = $this->extractPayload($estimate_request);

    // Resolve duplicates.
    $matches = $this->contactResolver->findMatches($payload);

    // Summary table.
    $form['summary'] = [
      '#type' => 'details',
      '#title' => $this->t('Contact details to use'),
      '#open' => TRUE,
    ];

    $rows = [
      [$this->t('Name'), $payload['name'] ?: '—'],
      [$this->t('Email'), $payload['email'] ?: '—'],
      [$this->t('Phone'), $payload['phone'] ?: '—'],
      [$this->t('Address'), $payload['address'] ?: '—'],
    ];

    $form['summary']['table'] = [
      '#type' => 'table',
      '#header' => [$this->t('Field'), $this->t('Value')],
      '#rows' => $rows,
    ];

    // If exact matches exist, show them and offer link options.
    $form['matches'] = [
      '#type' => 'details',
      '#title' => $this->t('Possible duplicates'),
      '#open' => !empty($matches['exact']),
    ];

    if (!empty($matches['exact'])) {
      $items = [];
      foreach ($matches['exact'] as $cid => $reason) {
        $items[] = $this->t('Contact ID @id (@reason)', ['@id' => (int) $cid, '@reason' => $reason]);
      }
      $form['matches']['exact_list'] = [
        '#theme' => 'item_list',
        '#items' => $items,
      ];

      // Provide link buttons for each exact match.
      $form['matches']['link_actions'] = [
        '#type' => 'container',
      ];

      foreach (array_keys($matches['exact']) as $cid) {
        $form['matches']['link_actions']["link_{$cid}"] = [
          '#type' => 'link',
          '#title' => $this->t('Link to Contact @id (recommended)', ['@id' => (int) $cid]),
          '#url' => Url::fromRoute('contract_residential.estimate_request_link_contact', [
            'estimate_request' => (int) $estimate_request->id(),
            'contact' => (int) $cid,
          ]),
          '#attributes' => [
            'class' => ['button', 'button--small'],
            'style' => 'margin-right: 10px;',
          ],
        ];
      }

      $form['matches']['note'] = [
        '#type' => 'markup',
        '#markup' => '<p><em>If one of the above is the same person, link instead of creating a duplicate.</em></p>',
      ];
    }
    else {
      $form['matches']['none'] = [
        '#type' => 'markup',
        '#markup' => '<p>No exact duplicates found by email or phone.</p>',
      ];
    }

    // Store payload in form state for submit.
    $form_state->set('payload', $payload);

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    /** @var array $payload */
    $payload = $form_state->get('payload') ?: [];

    // Final safety check: do not overwrite if something linked in the meantime.
    if ($this->estimateRequest->hasField('field_contact') && !$this->estimateRequest->get('field_contact')->isEmpty()) {
      $this->messenger()->addWarning('A Contact was linked while you were on this page. No changes made.');
      $form_state->setRedirectUrl($this->estimateRequest->toUrl('canonical'));
      return;
    }

    $result = $this->contactCreator->createContactAndLinkToRequest($this->estimateRequest, $payload);

    if ($result['ok'] ?? FALSE) {
      $this->messenger()->addStatus($this->t('Created Contact @cid and linked it to Estimate Request @rid.', [
        '@cid' => (int) ($result['contact_id'] ?? 0),
        '@rid' => (int) $this->estimateRequest->id(),
      ]));
    }
    else {
      $this->messenger()->addError($this->t('Failed to create Contact. See logs for details.'));
    }

    $form_state->setRedirectUrl($this->estimateRequest->toUrl('canonical'));
  }

  /**
   * Extract intake payload from estimate_request fields.
   */
  private function extractPayload(EntityInterface $req): array {
    $name = $req->hasField('field_requestor_name') ? trim((string) ($req->get('field_requestor_name')->value ?? '')) : '';
    $email = $req->hasField('field_requestor_email') ? strtolower(trim((string) ($req->get('field_requestor_email')->value ?? ''))) : '';
    $phone = $req->hasField('field_requestor_phone') ? trim((string) ($req->get('field_requestor_phone')->value ?? '')) : '';
    $address = $req->hasField('field_requestor_address') ? trim((string) ($req->get('field_requestor_address')->value ?? '')) : '';

    return [
      'name' => $name,
      'email' => $email,
      'phone' => $phone,
      'address' => $address,
    ];
  }

}
