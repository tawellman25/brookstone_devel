<?php

declare(strict_types=1);

namespace Drupal\contract_residential\Service;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Creates Contacts (contacts/contact) and links them to Estimate Requests.
 */
final class ContactCreator {

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly LoggerChannelFactoryInterface $loggerFactory,
  ) {}

  /**
   * Create a Contact and set estimate_request.field_contact.
   *
   * @return array{ok: bool, contact_id?: int}
   */
  public function createContactAndLinkToRequest(EntityInterface $estimate_request, array $payload): array {
    if ($estimate_request->getEntityTypeId() !== 'estimate_request') {
      return ['ok' => FALSE];
    }
    if (!$estimate_request->hasField('field_contact')) {
      return ['ok' => FALSE];
    }

    $name = trim((string) ($payload['name'] ?? ''));
    $email = strtolower(trim((string) ($payload['email'] ?? '')));
    $phone = trim((string) ($payload['phone'] ?? ''));
    $address = trim((string) ($payload['address'] ?? ''));

    // Parse requestor_name into first/last as best-effort.
    [$first, $last] = $this->splitName($name);

    try {
      $contact_storage = $this->entityTypeManager->getStorage('contacts');

      $values = [
        'type' => 'contact',
        'field_first_name' => $first,
        'field_last_name' => $last,
      ];

      if ($email !== '') {
        $values['field_email'] = $email;
      }
      if ($address !== '') {
        $values['field_address'] = $address;
      }

      /** @var \Drupal\Core\Entity\EntityInterface $contact */
      $contact = $contact_storage->create($values);

      // Set label key if supported (ECK/Contacts usually has one).
      $label_key = $contact->getEntityType()->getKey('label');
      if (is_string($label_key) && $label_key !== '' && $contact->hasField($label_key)) {
        $label = $this->buildContactLabel($first, $last, $email);
        if ($label !== '') {
          $contact->set($label_key, $label);
        }
      }

      $contact->save();

      // Phone number is an entity reference in your model.
      // We'll best-effort create the referenced phone entity and attach it.
      if ($phone !== '' && $contact->hasField('field_phone_number')) {
        $this->attachPhoneEntityIfPossible($contact, $phone);
      }

      // Link back to estimate request.
      $estimate_request->set('field_contact', ['target_id' => (int) $contact->id()]);
      $estimate_request->save();

      return ['ok' => TRUE, 'contact_id' => (int) $contact->id()];
    }
    catch (\Throwable $e) {
      $this->loggerFactory->get('contract_residential')->error(
        'ContactCreator failed for Estimate Request @rid: @msg',
        ['@rid' => (int) $estimate_request->id(), '@msg' => $e->getMessage()]
      );
      return ['ok' => FALSE];
    }
  }

  private function splitName(string $name): array {
    $name = trim(preg_replace('/\s+/', ' ', $name) ?? '');
    if ($name === '') {
      return ['', ''];
    }

    // If "Last, First" format.
    if (str_contains($name, ',')) {
      [$last, $first] = array_map('trim', explode(',', $name, 2));
      return [$first ?? '', $last ?? ''];
    }

    $parts = explode(' ', $name);
    if (count($parts) === 1) {
      return [$parts[0], ''];
    }

    $first = array_shift($parts);
    $last = implode(' ', $parts);
    return [$first, $last];
  }

  private function buildContactLabel(string $first, string $last, string $email): string {
    $full = trim(($first . ' ' . $last));
    if ($full !== '') {
      return $full;
    }
    return $email;
  }

  /**
   * Best-effort attach a phone entity to contacts.field_phone_number.
   * This introspects the reference target and tries common storage fields.
   */
  private function attachPhoneEntityIfPossible(EntityInterface $contact, string $phone): void {
    try {
      $field_def = $contact->getFieldDefinition('field_phone_number');
      $settings = $field_def ? $field_def->getSettings() : [];
      $target_type = (string) ($settings['target_type'] ?? '');

      if ($target_type === '') {
        return;
      }

      $phone_storage = $this->entityTypeManager->getStorage($target_type);

      // Determine target bundle if constrained.
      $handler_settings = $settings['handler_settings'] ?? [];
      $target_bundles = $handler_settings['target_bundles'] ?? [];
      $bundle = '';
      if (!empty($target_bundles)) {
        // Take the first allowed bundle.
        $bundle = (string) array_key_first($target_bundles);
      }

      $create = [];
      if ($bundle !== '') {
        // Most entities use 'type' as bundle key, but not all.
        // We'll detect bundle key from entity type definition.
        $def = $this->entityTypeManager->getDefinition($target_type);
        $bundle_key = (string) ($def->getKey('bundle') ?? 'type');
        $create[$bundle_key] = $bundle;
      }

      /** @var \Drupal\Core\Entity\EntityInterface $phone_entity */
      $phone_entity = $phone_storage->create($create);

      // Set label/title if possible.
      $label_key = $phone_entity->getEntityType()->getKey('label');
      if (is_string($label_key) && $label_key !== '' && $phone_entity->hasField($label_key)) {
        $phone_entity->set($label_key, $phone);
      }

      // Populate a plausible phone value field if present.
      foreach (['field_phone_number', 'field_phone', 'field_number', 'field_value'] as $fname) {
        if ($phone_entity->hasField($fname)) {
          $phone_entity->set($fname, $phone);
          break;
        }
      }

      $phone_entity->save();

      // Attach to contact.
      $contact->get('field_phone_number')->appendItem(['target_id' => (int) $phone_entity->id()]);
      $contact->save();
    }
    catch (\Throwable $e) {
      // Don’t fail the whole operation if phone entity creation is not compatible.
      $this->loggerFactory->get('contract_residential')->warning(
        'Phone entity attach skipped for Contact @cid: @msg',
        ['@cid' => (int) $contact->id(), '@msg' => $e->getMessage()]
      );
    }
  }

}
