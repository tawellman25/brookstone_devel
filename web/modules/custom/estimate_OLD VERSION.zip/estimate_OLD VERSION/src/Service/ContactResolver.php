<?php

declare(strict_types=1);

namespace Drupal\contract_residential\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Finds potential duplicate Contacts by email/phone.
 */
final class ContactResolver {

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly LoggerChannelFactoryInterface $loggerFactory,
  ) {}

  /**
   * @return array{exact: array<int,string>}
   *   exact matches keyed by contact id with reason string.
   */
  public function findMatches(array $payload): array {
    $exact = [];

    $email = strtolower(trim((string) ($payload['email'] ?? '')));
    $phone_raw = trim((string) ($payload['phone'] ?? ''));
    $phone_norm = $this->normalizePhone($phone_raw);

    // 1) Email exact match (best signal).
    if ($email !== '') {
      try {
        $storage = $this->entityTypeManager->getStorage('contacts');
        $ids = $storage->getQuery()
          ->accessCheck(FALSE)
          ->condition('type', 'contact')
          ->condition('field_email', $email)
          ->range(0, 10)
          ->execute();

        foreach (array_keys($ids) as $cid) {
          $exact[(int) $cid] = 'email match';
        }
      }
      catch (\Throwable $e) {
        $this->loggerFactory->get('contract_residential')->error('ContactResolver email match failed: @msg', [
          '@msg' => $e->getMessage(),
        ]);
      }
    }

    // 2) Phone match (best-effort: loads candidate contacts and compares referenced phone entities).
    // We cannot reliably entityQuery across an entity_reference to a custom "Phone Number" entity
    // without knowing its storage fields, so we do a bounded scan of "recent-ish" contacts.
    if ($phone_norm !== '') {
      try {
        $storage = $this->entityTypeManager->getStorage('contacts');

        // Get a bounded set of contacts to check. Adjust range if you want.
        $candidate_ids = $storage->getQuery()
          ->accessCheck(FALSE)
          ->condition('type', 'contact')
          ->sort('id', 'DESC')
          ->range(0, 250)
          ->execute();

        if (!empty($candidate_ids)) {
          $candidates = $storage->loadMultiple(array_values($candidate_ids));
          foreach ($candidates as $contact) {
            if (!$contact->hasField('field_phone_number') || $contact->get('field_phone_number')->isEmpty()) {
              continue;
            }
            foreach ($contact->get('field_phone_number')->referencedEntities() as $phone_entity) {
              $candidate = $this->extractPhoneFromEntity($phone_entity);
              if ($candidate !== '' && $this->normalizePhone($candidate) === $phone_norm) {
                $cid = (int) $contact->id();
                // Don't override email reason if already present.
                $exact[$cid] = $exact[$cid] ?? 'phone match';
              }
            }
          }
        }
      }
      catch (\Throwable $e) {
        $this->loggerFactory->get('contract_residential')->error('ContactResolver phone match failed: @msg', [
          '@msg' => $e->getMessage(),
        ]);
      }
    }

    return ['exact' => $exact];
  }

  private function normalizePhone(string $phone): string {
    $digits = preg_replace('/\D+/', '', $phone) ?? '';
    // Normalize leading 1 for US numbers.
    if (strlen($digits) === 11 && str_starts_with($digits, '1')) {
      $digits = substr($digits, 1);
    }
    return $digits;
  }

  /**
   * Best-effort extraction of phone from a referenced phone entity.
   */
  private function extractPhoneFromEntity(object $entity): string {
    // Try common field names first.
    foreach (['field_phone_number', 'field_phone', 'field_number', 'field_value'] as $fname) {
      if (method_exists($entity, 'hasField') && $entity->hasField($fname) && !$entity->get($fname)->isEmpty()) {
        return (string) ($entity->get($fname)->value ?? '');
      }
    }

    // Fall back to label if available.
    if (method_exists($entity, 'label')) {
      return (string) $entity->label();
    }

    return '';
  }

}
